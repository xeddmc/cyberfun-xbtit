<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Postannut";
$language["POSTED_DATE"] = "Postauksen p&auml;iv&auml;m&auml;&auml;r&auml;";
$language["TITLE"]       = "Otsikko";
$language["ADD"]         = "Lis&auml;&auml;";

?>
