<?php
$language['charset']='ISO-8859-1';
$language['DELETE_READED'] = 'Radera';
$language['USER_LANGUE'] = 'Spr�k';
$language['USER_STYLE'] = 'Stil';
$language['CURRENTLY_PEER'] = 'Du seedar eller leechar en torrent just nu.';
$language['STOP_PEER'] = 'Du m�ste stoppa din client.';
$language['USER_PWD_AGAIN'] = 'Upprepa l�senord';
$language['EMAIL_FAILED'] = 'Utskick av e-post misslyckades!';
$language['NO_SUBJECT'] = 'Inget �mne';
$language['MUST_ENTER_PASSWORD'] = '<br/><font color="#FF0000"><strong>Du m�ste ange ditt l�senord f�r att �ndra inst�llningarna ovan.</strong></font>';
$language['ERR_PASS_WRONG'] = 'L�senord saknades eller fel uppstod. Inga �ndringar genomf�rdes.';
$language['MSG_DEL_ALL_PM'] = 'Om du v�ljer pm som inte �r l�sta, kommer de inte bli raderade';
$language['ERR_PM_GUEST'] = 'Du kan inte skicka PM till dig sj�lv!';
?>