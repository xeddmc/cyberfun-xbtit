<?php
$language["BLOCK_USER"]="Felhasználó Infó";
$language["BLOCK_INFO"]="Tracker Infó";
$language["BLOCK_MENU"]="Főmenü";
$language["BLOCK_CLOCK"]="Idő";
$language["BLOCK_FORUM"]="Fórum";
$language["BLOCK_LASTMEMBER"]="Legújabb tagunk";
$language["BLOCK_ONLINE"]="Jelenlevők";
$language["BLOCK_ONTODAY"]="Előző nap";
$language["BLOCK_SHOUTBOX"]=" Üzifal ";
$language["BLOCK_TOPTORRENTS"]="Top Torrent";
$language["BLOCK_LASTTORRENTS"]="Legutóbb feltöltve";
$language["BLOCK_NEWS"]="Legújabb hír";
$language["BLOCK_SERVERLOAD"]="Server töltés";
$language["BLOCK_POLL"]="Szavazás";
$language["BLOCK_SEEDWANTED"]="Seed-eld az alábbi filet ha módodban áll!!!";
$language["BLOCK_PAYPAL"]="Támogatás";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Tracker Eszköztár";
$language["BLOCK_MAINUSERTOOLBAR"]="Felhasználói Eszköztá";
$language["WELCOME_LASTUSER"]="Köszöntelek az oldalon";
$language["BLOCK_MINCLASSVIEW"]="Minimális jogosultság";
$language["BLOCK_MAXCLASSVIEW"]="Maximális jogosultság";
?>