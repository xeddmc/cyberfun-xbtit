<?php
$language['INSERT_USERNAME']='�Debes insertar un nombre de usuario!';
$language['INSERT_PASSWORD']='�Debes insertar una contrase�a!';
?>