<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language['POSTED_BY']   = 'Enviado por';
$language['POSTED_DATE'] = 'Fecha de publicaci�n';
$language['TITLE']       = 'T�tulo';
$language['ADD']         = 'A�adir';

?>
