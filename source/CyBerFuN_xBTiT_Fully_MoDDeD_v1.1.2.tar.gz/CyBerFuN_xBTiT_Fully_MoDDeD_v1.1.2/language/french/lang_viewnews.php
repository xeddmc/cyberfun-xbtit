<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Post� par";
$language["POSTED_DATE"] = "Post� le";
$language["TITLE"]       = "Titre";
$language["ADD"]         = "Ajouter";

?>
