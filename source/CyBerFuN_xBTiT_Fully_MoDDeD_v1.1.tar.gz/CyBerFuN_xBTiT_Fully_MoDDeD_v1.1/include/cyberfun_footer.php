<?php
$cyberfun_footer = "[&nbsp;&nbsp;<u>xBTiT FuLLy MoDDeD By cybernet</u>: <a href=\"http://xList.ro/\" target=\"_blank\">xList Tracker</a>&nbsp;]
[&nbsp;&nbsp;<u>xbtit '.$tracker_version.' By</u>: <a href=\"http://www.btiteam.org/\" target=\"_blank\">Btiteam</a>&nbsp;]";
?>
