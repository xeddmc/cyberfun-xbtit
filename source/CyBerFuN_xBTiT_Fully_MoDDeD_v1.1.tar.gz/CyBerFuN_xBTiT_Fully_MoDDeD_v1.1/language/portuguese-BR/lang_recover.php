<?php
$language["ERR_NO_EMAIL"]="Você precisa fornecer um endereço de e-mail";
$language["ERR_INV_EMAIL"]="É preciso digitar um endereço de email válido";
$language["ERR_NO_CAPTCHA"]="É necessário digitar o código da Imagem";
$language["IMAGE_CODE"]="código da Imagem";
$language["SECURITY_CODE"]="Responda a pergunta";
$language["RECOVER_EMAIL_1"]="\nAlguém, esperamos que você, solicitou que a senha para a conta associada a este endereço de e-mail (%s) Ser redefinidos.\n\nO pedido originalmente de %s.\n\nSe você não fez ignore este e-mail. Não responda..\n\nSSe você quiser confirmar este pedido, siga este link:\n\n%s\n\n	Depois que você fizer isso, sua senha será reinicializada e enviada de volta para você.\n--\n%s";
$language["RECOVER_EMAIL_2"]="\nConforme seu pedido, foi gerado uma nova senha para a sua conta.\n\nVeja aqui as informações que temos agora em arquivo para esta conta:\n\n    Nome de Usuário: %s\n    Senha: %s\n\nVocê pode entrar em %s\n\n--\n%s";
?>
