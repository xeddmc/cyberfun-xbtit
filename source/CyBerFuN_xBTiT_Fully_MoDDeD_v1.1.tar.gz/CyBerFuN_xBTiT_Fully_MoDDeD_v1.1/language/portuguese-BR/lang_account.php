<?php
$language["ACCOUNT_CREATED"]="Conta Criada";
$language["USER_NAME"]="Usuário";
$language["USER_PWD_AGAIN"]="Repita a senha";
$language["USER_PWD"]="Senha";
$language["USER_STYLE"]="Estilo";
$language["USER_LANGUE"]="Idioma";
$language["IMAGE_CODE"]="Código da Imagem";
$language["INSERT_USERNAME"]="Você deve inserir um nome de usuário!";
$language["INSERT_PASSWORD"]="Você deve inserir uma senha!";
$language["DIF_PASSWORDS"]="As senhas não correspondem!";
$language["ERR_NO_EMAIL"]="É preciso digitar um endereço de email válido";
$language["USER_EMAIL_AGAIN"]="Repita o e-mail";
$language["ERR_NO_EMAIL_AGAIN"]="Repita o e-mail";
$language["DIF_EMAIL"]="Os e-mails não correspondem!";
$language["SECURITY_CODE"]="Responda a pergunta";
# Password strength
$language["WEEK"]="Fraco";
$language["MEDIUM"]="Media";
$language["SAFE"]="Segura";
$language["STRONG"]="Forte";

?>
