<?php

// USERDETAILS.PHP LANGUAGE FILE

$language["MEMBER"]             = "Mitglied";
$language["USERNAME"]           = "Benutzername";
$language["EMAIL"]              = "Email";
$language["LAST_IP"]            = "Letzte Ip";
$language["USER_LEVEL"]         = "Rang";
$language["USER_JOINED"]        = "Eintritt";
$language["USER_LASTACCESS"]    = "Letzter Zugriff";
$language["PEER_COUNTRY"]       = "Land";
$language["USER_LOCAL_TIME"]    = "Benutzer Ortszeit";
$language["DOWNLOADED"]         = "downloaded";
$language["UPLOADED"]           = "uploaded";
$language["RATIO"]              = "Verh�ltnis";
$language["FORUM"]              = "Forum";
$language["POSTS"]              = "Beitr�ge";
$language["POSTS_PER_DAY"]      = "%s Beitr�ge pro Tag";
$language["TORRENTS"]           = "Torrents";
$language["FILE"]               = "Datei";
$language["ADDED"]              = "Hinzugef�gt";
$language["SIZE"]               = "Gr�sse";
$language["SHORT_S"]            = "S";
$language["SHORT_L"]            = "L";
$language["SHORT_C"]            = "C";
$language["NO_TORR_UP_USER"]    = "Benutzer hat noch keinen Torrent hochgeladen!";
$language["ACTIVE_TORRENT"]     = "Aktive Torrents";
$language["PEER_STATUS"]        = "Status";
$language["NO_ACTIVE_TORR"]     = "Nicht aktive Torrents";
$language["PEER_CLIENT"]        = "Client";
$language["EDIT"]               = "Bearbeiten";
$language["DELETE"]             = "L�schen";
$language["PM"]                 = "PM";
$language["BACK"]               = "Zur�ck";
$language["NO_HISTORY"]         = "Keine Statistik vorhanden...";
?>