<?php

// ENGLISH USERS.PHP FILE

$language["MEMBER"]          = "Mitglied";
$language["FIND_USER"]       = "Finde Benutzer";
$language["USER_LEVEL"]      = "Benutzer Ebene";
$language["ALL"]             = "Alle";
$language["SEARCH"]          = "Suchen";
$language["USER_NAME"]       = "Benutzername";
$language["USER_LEVEL"]      = "Benutzerebene";
$language["USER_JOINED"]     = "Eintritt";
$language["USER_LASTACCESS"] = "Letzter Zugriff";
$language["USER_COUNTRY"]    = "Land";
$language["RATIO"]           = "Verh�ltnis";
$language["USERS_PM"]        = "PM";
$language["EDIT"]            = "Bearbeiten";
$language["DELETE"]          = "L�schen";
$language["NO_USERS_FOUND"]  = "Keine Benutzer gefunden!";
$language["UNKNOWN"]         = "Unbekannt";

?>