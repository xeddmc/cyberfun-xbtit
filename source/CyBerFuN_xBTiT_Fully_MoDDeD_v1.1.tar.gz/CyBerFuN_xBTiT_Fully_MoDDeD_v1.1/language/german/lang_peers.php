<?php

$language["PEER_PROGRESS"]="Fortschritt";
$language["PEER_COUNTRY"]="Land";
$language["PEER_PORT"]="Port";
$language["PEER_STATUS"]="Status";
$language["PEER_CLIENT"]="Client";
$language["NO_PEERS"]="Keine Peers";
?>