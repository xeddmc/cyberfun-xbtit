<?php
$language['charset']='ISO-8859-1';
$language['POSTED_BY'] = 'Av';
$language['POSTED_DATE'] = 'Publicerades';
$language['TITLE'] = 'Titel';
$language['ADD'] = 'L�gg till';
?>
