<?php
//AJAX Poll System Hack Start - 5:03 PM 3/24/2007
$language['charset']='ISO-8859-1';
$language['POLL_ID'] = 'ID';
$language['LATEST_POLL'] = 'Nyaste fr�gan';
$language['CAST_VOTE'] = 'Kasta min r�stning';
$language['FETCHING_RESULTS'] = 'F� fr�geresultatet. Sn�lla v�nta...';
$language['POLL_TITLE'] = 'Fr�gans Titel';
$language['POLL_TITLE_MISSING'] = 'Fr�ge titeln saknas';
$language['POLLING_SYSTEM'] = 'AJAX Fr�ga System';
$language['CURRENT_POLLS'] = 'Aktuell fr�gor';
$language['POLL_STARTED'] = 'fr�gan Startades';
$language['POLL_ENDED'] = 'Fr�gan Slutates';
$language['POLL_LASTED'] = 'Nyaste';
$language['POLL_BY'] = 'Startad av';
$language['POLL_VOTES'] = 'R�sta';
$language['POLL_STILL_ACTIVE'] = 'Fortfarande Aktiv';
$language['POLL_NEW'] = 'Ny';
$language['POLL_START_NEW'] = 'Starta Ny Fr�ga';
$language['POLL_ACTIVE'] = 'Aktiv';
$language['POLL_ACTIVE_TRUE'] = 'Aktive';
$language['POLL_ACTIVE_FALSE'] = 'Inaktiv';
$language['POLL_OPTION'] = 'Inst�llning';
$language['POLL_OPTIONS'] = 'Inst�llningar';
$language['POLL_MOVE'] = 'Flytta ner';
$language['POLL_NEW_OPTIONS'] = 'Ny Inst�llning';
$language['POLL_SAVE'] = 'Spara';
$language['POLL_CANCEL'] = 'Avbryt';
$language['POLL_DELETE'] = 'Radera';
$language['POLL_DEL_CONFIRM'] = 'Tryck OK F�r att ta bort denna fr�ga';
$language['POLL_VOTERS'] = 'R�stare';
$language['POLL_IP_ADDRESS'] = 'IP Address';
$language['POLL_DATE'] = 'Datum';
$language['POLL_USER'] = 'Anv�ndare';
$language['POLL_ACCOUNT_DEL'] = '<i>Kontot �r raderat</i>';
$language['POLL_BACK'] = 'Tillbaka';
$language['YEAR'] = '�r';
$language['MONTH'] = 'm�nad';
$language['WEEK'] = 'vecka';
$language['DAY'] = 'dag';
$language['HOUR'] = 'timme';
$language['MINUTE'] = 'minut';
$language['SECOND'] = 'sekund';
$language['YEARS'] = '�r';
$language['MONTHS'] = 'm�nader';
$language['WEEKS'] = 'Veckor';
$language['DAYS'] = 'dagar';
$language['HOURS'] = 'timmar';
$language['MINUTES'] = 'minuter';
$language['SECONDS'] = 'sekunder';
//AJAX Poll System Hack Stop

?>