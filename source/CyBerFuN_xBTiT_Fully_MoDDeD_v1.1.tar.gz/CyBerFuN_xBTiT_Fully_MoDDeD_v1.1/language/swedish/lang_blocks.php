<?php
$language['BLOCK_USER'] = 'Anv�ndar Information';
$language['BLOCK_INFO'] = 'Tracker Information';
$language['BLOCK_MENU'] = 'Huvudmenyn';
$language['BLOCK_CLOCK'] = 'Klocka';
$language['BLOCK_FORUM'] = 'Forum';
$language['BLOCK_LASTMEMBER'] = 'Senast Registrerad';
$language['BLOCK_ONLINE'] = 'Online';
$language['BLOCK_ONTODAY'] = 'Idag';
$language['BLOCK_SHOUTBOX'] = 'Shoutbox';
$language['BLOCK_TOPTORRENTS'] = 'Popul�raste Torrents';
$language['BLOCK_LASTTORRENTS'] = 'Senaste Torrents';
$language['BLOCK_NEWS'] = 'Nyheter';
$language['BLOCK_SERVERLOAD'] = 'Server Belastning';
$language['BLOCK_POLL'] = 'Omr�stning';
$language['BLOCK_SEEDWANTED'] = 'Beh�ver Seeds';
$language['BLOCK_PAYPAL'] = 'Donera';
$language['BLOCK_MAINTRACKERTOOLBAR'] = 'Trackerns Huvudmeny';
$language['BLOCK_MAINUSERTOOLBAR'] = 'Anv�ndarmenyn';
$language['WELCOME_LASTUSER'] = ' V�lkommen till v�ran tracker ';
$language['BLOCK_MINCLASSVIEW'] = 'Minsta rank som kan visa detta';
$language['BLOCK_MAXCLASSVIEW'] = 'H�gsta rank som Kan Visa detta';
$language["BLOCK_CAT"]="Kategori";

$language["BLOCK_FEATURED"]="Favorit Torrent";
?>