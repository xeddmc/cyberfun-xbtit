<?php

// Translated to Vietnamese Language by VoTienSinh  & ThanhThanh for www.diemthuy.nl

$language["BLOCK_USER"]="th&#244;ng tin v&#7873; th&#224;nh vi&#234;n"; 
$language["BLOCK_INFO"]="th&#244;ng tin c&#7911;a di&#7875;n &#273;&#224;n"; 
$language["BLOCK_MENU"]="trang ch&#237;nh"; 
$language["BLOCK_CLOCK"]="&#273;&#7891;ng h&#7891;";  
$language["BLOCK_FORUM"]="di&#7875;n &#273;&#224;n";  
$language["BLOCK_LASTMEMBER"]="th&#224;nh vi&#234;n m&#7899;i nh&#7845;t"; 
$language["BLOCK_ONLINE"]="tr&#7921;c tuy&#7871;n";  
$language["BLOCK_ONTODAY"]="v&#224;o h&#244;m nay";  
$language["BLOCK_SHOUTBOX"]="n&#417;i t&#226;m s&#7921;, ph&#225;t bi&#7875;u";  
$language["BLOCK_TOPTORRENTS"]="torrent &#273;&#432;&#7907;c &#432;u chu&#7897;ng";  
$language["BLOCK_LASTTORRENTS"]="t&#7843;i l&#234;n cu&#7889;i c&#249;ng"; 
$language["BLOCK_NEWS"]="tin t&#7913;c m&#7899;i nh&#7845;t"; 
$language["BLOCK_SERVERLOAD"]="n&#7841;p v&#224;o kho d&#7917; li&#7879;u";  
$language["BLOCK_POLL"]="th&#259;m d&#242; &#253; ki&#7871;n";
$language["BLOCK_SEEDWANTED"]="nh&#7919;ng torrent c&#7847;n t&#7843;i l&#234;n"; 
$language["BLOCK_PAYPAL"]="&#7911;ng h&#7897; ch&#250;ng t&#244;i";  
$language["BLOCK_MAINTRACKERTOOLBAR"]="ph&#7847;n &#273;i&#7873;u ch&#7881;nh c&#7911;a di&#7875;n &#273;&#224;n";  
$language["BLOCK_MAINUSERTOOLBAR"]="ph&#7847;n &#273;i&#7873;u khi&#7875;n ch&#237;nh c&#7911;a th&#224;nh vi&#234;n";  
$language["WELCOME_LASTUSER"]="ch&#224;o m&#7915;ng c&#225;c b&#7841;n";  
$language["BLOCK_MINCLASSVIEW"]="c&#7845;p b&#7853;t &#237;t nh&#7845;t &#273;&#7875; c&#243; th&#7875; xem";  
$language["BLOCK_MAXCLASSVIEW"]="c&#7845;p b&#7853;t t&#7889;i &#273;a &#273;&#7875; c&#243; th&#7875; xem";  

$language["BLOCK_LINKS"]="trang web hay";
$language["BLOCK_QS"]="t&#236;m nhanh";
$language["Rand_block"]="h&#236;nh &#7843;nh &#273;&#7865;p";
$language["Chess_block"]="c&#7901; t&#432;&#7899;ng";
$language["BLOCK_BIRTHDAY"]="sinh nh&#7853;t h&#244;m nay";
$language["BLOCK_NO_BIRTHDAY"]="h&#244;m nay kh&#244;ng c&#243; ai sinh nh&#7853;t";
$language["CLIENT"]="ph&#7847;n m&#7873;m n&#234;n d&#249;ng";
$language["BLOCK_FEATURED"]="torrent m&#7899;i";




?>