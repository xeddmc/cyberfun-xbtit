<?php

// Translated to Vietnamese Language by VoTienSinh  & ThanhThanh for www.diemthuy.nl

$language["NOT_SHA"]="Ch&#7913;c n&#259;ng SHA1 kh&#244;ng c&#243; s&#7861;n &#273;&#7875; d&#249;ng. B&#7841;n c&#7847;n  PHP 4.3.0 hay t&#7889;t h&#417;n.";
$language["NOT_AUTHORIZED_UPLOAD"]="B&#7841;n kh&#244;ng &#273;&#432;&#7907;c ph&#233;p &#273;&#7875; t&#7843;i l&#234;n!";
$language["FILE_UPLOAD_ERROR_1"]="Kh&#244;ng th&#7875; &#273;&#7885;c t&#224;i li&#7879;u &#273;&#432;a l&#234;n";
$language["FILE_UPLOAD_ERROR_3"]="&#273;&#7897; l&#7899;n c&#7911;a t&#224;i li&#7879;u l&#224; kh&#244;ng";
$language["FACOLTATIVE"]=" kh&#244;ng b&#7855;t bu&#7897;c, t&#249;y &#253; ";
$language["FILE_UPLOAD_ERROR_2"]="T&#224;i li&#7879;u t&#7843;i l&#234;n b&#7883; tr&#7909;c tr&#7863;c";
$language["ERR_PARSER"]="H&#236;nh nh&#432; c&#243; &#273;i&#7875;m sai t&#7841;i torrent c&#7911;a b&#7841;n. Ph&#226;n t&#237;ch ng&#7919; ph&#225;p (t&#7915;, c&#226;u) kh&#244;ng ch&#7845;p nh&#7853;n n&#243;.";
$language["WRITE_CATEGORY"]="B&#7841;n ph&#7843;i &#273;&#7883;nh r&#7887; torrent lo&#7841;i n&#224;o...";
$language["DOWNLOAD"]="T&#7843;i xu&#7889;ng";
$language["MSG_UP_SUCCESS"]="T&#7843;i l&#234;n th&#224;nh c&#244;ng! Torrent &#273;&#227; &#273;&#432;&#7907;c th&#234;m v&#224;o.";
$language["MSG_DOWNLOAD_PID"]="H&#7879; th&#7889;ng PID &#273;&#227; nh&#7853;n torrent v&#7899;i PID c&#7911;a b&#7841;n";
$language["EMPTY_DESCRIPTION"]="B&#7841;n ph&#7843;i th&#234;m cho s&#7921; di&#7877;n t&#7843;!";
$language["EMPTY_ANNOUNCE"]=" N&#417;i tuy&#234;n b&#7889; th&#236; tr&#7889;ng kh&#244;ng";
$language["FILE_UPLOAD_ERROR_1"]="T&#224;i li&#7879;u &#273;&#432;a l&#234;n kh&#244;ng th&#7875; &#273;&#7885;c &#273;&#432;&#7907;c";
$language["FILE_UPLOAD_ERROR_2"]="T&#224;i li&#7879;u &#273;&#432;a l&#234;n b&#7883; tr&#7909;c tr&#7863;c";
$language["FILE_UPLOAD_ERROR_3"]="&#273;&#7897; l&#7899;n c&#7911;a t&#224;i li&#7879;u l&#224; kh&#244;ng";
$language["NO_SHA_NO_UP"]="T&#224;i li&#7879;u &#273;ang &#273;&#432;a l&#234;n kh&#244;ng s&#7861;n s&#224;ng &#273;&#7875; d&#249;ng - kh&#244;ng c&#243; ch&#7913;c n&#259;ng SHA1.";
$language["NOT_SHA"]="Ch&#7913;c n&#259;ng SHA1 kh&#244;ng c&#243; s&#7861;n &#273;&#7875; d&#249;ng. B&#7841;n c&#7847;n  PHP 4.3.0 hay t&#7889;t h&#417;n.";
$language["ERR_PARSER"]="H&#236;nh nh&#432; c&#243; &#273;i&#7875;m sai t&#7841;i torrent c&#7911;a b&#7841;n. Ph&#226;n t&#237;ch ng&#7919; ph&#225;p (t&#7915;, c&#226;u) kh&#244;ng ch&#7845;p nh&#7853;n n&#243;.";
$language["WRITE_CATEGORY"]="B&#7841;n ph&#7843;i &#273;&#7883;nh r&#7887; torrent lo&#7841;i n&#224;o...";
$language["ERR_HASH"]="Chi ti&#7871;t c&#7911;a th&#244;ng tin ph&#7843;i &#273;&#250;ng 40 hex bytes.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Torrent t&#7915; b&#234;n ngo&#224;i kh&#244;ng ch&#7845;p nh&#7853;n";
$language["ERR_MOVING_TORR"]="Tr&#7909;c tr&#7863;c trong l&#250;c t&#7843;i torrent...";
$language["ERR_ALREADY_EXIST"]="Torrent n&#224;y &#273;&#227; c&#243; s&#7861;n trong kho d&#7917; li&#7879;u c&#7911;a ch&#250;ng t&#244;i.";
$language["MSG_DOWNLOAD_PID"]="H&#7879; th&#7889;ng PID &#273;&#227; nh&#7853;n torrent v&#7899;i PID c&#7911;a b&#7841;n";
$language["MSG_UP_SUCCESS"]="T&#7843;i l&#234;n th&#224;nh c&#244;ng! Torrent &#273;&#227; &#273;&#432;&#7907;c th&#234;m v&#224;o.";

?>