<?php
$language['ERR_NO_EMAIL']='Debes especificar un email';
$language['ERR_INV_EMAIL']='Debes escribir una direccion de email valida';
$language['ERR_NO_CAPTCHA']='Escribe el c�digo de la imagen';
$language['IMAGE_CODE']='C�digo de Imagen';
$language['SECURITY_CODE']='Responde la pregunta';
$language['RECOVER_EMAIL_1']='\nAlguien quiere reestablecer la contrase�a asociada a este email (%s).\n\n La petici�n fue originada desde %s.\n\nSi no has sido tu, ignora este email.\n\nSi desea confirmar esta petici�n, haz click en el link:\n\n%s\n\n Despu�s de esto tu contrase�a se reseteara y se te enviar� por email.\n--\n%s';
$language['RECOVER_EMAIL_2']='\nTal y como pediste se te ha generado una nueva contrase�a para tu cuenta.\n\nAqu� tienes la nueva informaci�n de tu cuenta:\n\n    Usuario: %s\n    Contrase�a: %s\n\nPuedes logearte en %s\n\n--\n%s';
?>