<?php
$language['PEER_PROGRESS']='Progreso';
$language['PEER_COUNTRY']='Pa�s';
$language['PEER_PORT']='Puerto';
$language['PEER_STATUS']='Estado';
$language['PEER_CLIENT']='Cliente';
$language['NO_PEERS']='No hay peers (pares)';
?>