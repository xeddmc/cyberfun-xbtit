<?php
$design_copyright = "[&nbsp;&nbsp;<u>xList Tracker By</u>: <a href=\"#\" target=\"_blank\">cybernet</a>&nbsp;]";
?>