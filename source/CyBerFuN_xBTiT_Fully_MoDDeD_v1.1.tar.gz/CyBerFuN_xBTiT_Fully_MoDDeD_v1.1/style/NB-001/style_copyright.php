<?php
$design_copyright = "[&nbsp;&nbsp;<u>xList By cybernet</u>: <a href=\"http://tracker.cyberfun.ro/\" target=\"_blank\">CyBerFuN Tracker</a>&nbsp;]
<script type=\"text/javascript\">
var gaJsHost = ((\"https:\" == document.location.protocol) ? \"https://ssl.\" : \"http://www.\");
document.write(unescape(\"%3Cscript src='\" + gaJsHost + \"google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E\"));
</script>
<script type=\"text/javascript\">
try {
var pageTracker = _gat._getTracker(\"UA-10155921-2\");
pageTracker._trackPageview();
} catch(err) {}</script>
<script src=\"http://script.top66.ro/id-453659/19/2/code2.js\" type=\"text/javascript\"></script>
<a href=\"http://www.top66.ro\"><img src=\"http://images.top66.ro/vote/19.gif\" alt=\"XList Tracker - Movies - Index Top66 Statistici\" usemap=\"#Top66Vote\" border=\"0\"></a>
<script type=\"text/javascript\">
var pkBaseURL = ((\"https:\" == document.location.protocol) ? \"https://stats.xlist.ro/\" : \"http://stats.xlist.ro/\");
document.write(unescape(\"%3Cscript src='\" + pkBaseURL + \"piwik.js' type='text/javascript'%3E%3C/script%3E\"));
</script><script type=\"text/javascript\">
try {
var piwikTracker = Piwik.getTracker(pkBaseURL + \"piwik.php\", 1);
piwikTracker.trackPageView();
piwikTracker.enableLinkTracking();
} catch( err ) {}
</script><noscript><p><img src=\"http://stats.xlist.ro/piwik.php?idsite=1\" style=\"border:0\" alt=\"\"/></p></noscript>
<script type=\"text/javascript\" language=\"javascript\"> 
var site_id = 18977; 
</script><script type=\"text/javascript\" language=\"javascript\" src=\"http://fx.gtopstats.com/js/gTOP.js\">
</script>
<noscript><a href=\"http://www.gtopstats.com/\">GTopstats.com - The most powerful web statistics system around </a></noscript>";
?>