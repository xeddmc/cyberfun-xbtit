<?php
$design_copyright='<a href="" target="_blank">X-NEON</a>';
$design_mod='<a href="http://daclapi.ath.cx" target="_blank">dada83</a>';
?>